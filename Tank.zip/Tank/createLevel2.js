let createTankEnimiesOfLevel = function (level) {
    if (level == 1) {
        __createTankEnimiesOfLevel(0, 19);
        __createTankEnimiesOfLevel(1, 1);
    }
    else if (level == 2) {
        __createTankEnimiesOfLevel(0, 30);
        __createTankEnimiesOfLevel(1, 2);
    }
    else if (level == 3) {
        __createTankEnimiesOfLevel(0, 20);
        __createTankEnimiesOfLevel(1, 10);
        __createTankEnimiesOfLevel(2, 10);
    }
    else if (level == 4) {
        __createTankEnimiesOfLevel(0, 20);
        __createTankEnimiesOfLevel(1, 10);
        __createTankEnimiesOfLevel(2, 10);
        __createTankEnimiesOfLevel(3, 10);
    }
    else if (level == 5) {
        __createTankEnimiesOfLevel(0, 20);
        __createTankEnimiesOfLevel(1, 10);
        __createTankEnimiesOfLevel(2, 10);
        __createTankEnimiesOfLevel(3, 10);
        __createTankEnimiesOfLevel(4, 10);
        createBossLevel5(1650, 380);
    }
    else if (level == 6) {
        __createTankEnimiesOfLevel(4, 20);
        createBossLevel5(1650, 150);
        createBossLevel5(1650, 380);
        createBossLevel5(1650, 610);
    }
    else if (level == 7) {
        __createTankEnimiesOfLevel(4, 20);
        __createTankEnimiesOfLevel(5, 5);
        createBossLevel5(1650, 150);
        createBossLevel5(1650, 380);
        createBossLevel5(1650, 610);
    }
    else if (level == 8) {
        __createTankEnimiesOfLevel(4, 15);
        __createTankEnimiesOfLevel(5, 10);
        createBossLevel5(1650, 150);
        createBossLevel5(1650, 380);
        createBossLevel5(1650, 610);
    }
    else if (level == 9) {
        __createTankEnimiesOfLevel(1, 20);
        __createTankEnimiesOfLevel(2, 20);
        __createTankEnimiesOfLevel(3, 20);
        __createTankEnimiesOfLevel(4, 20);
        __createTankEnimiesOfLevel(5, 2);
        createBossLevel5(1650, 150);
        createBossLevel5(1650, 380);
        createBossLevel5(1650, 610);
    }
    else if (level == 10) {
        createBossLevel10(1400, 385);
    }

    groupTanksEnimies.forEach(tankC => {
        fireComputer(tankC);
        computerFindPlayers(tankC);
    });
    game.physics.enable(groupTanksEnimies, Phaser.Physics.ARCADE);

    game.physics.enable(groupBossLevel5, Phaser.Physics.ARCADE);
    groupBossLevel5.forEach(bossLevel5 => {
        fireComputer(bossLevel5);
    });
    game.world.bringToTop(groupBossLevel5);

    game.physics.enable(groupBossLevel10, Phaser.Physics.ARCADE);
    game.world.bringToTop(groupBossLevel10);
    if(stickDpadClone)
        game.world.bringToTop(stickDpadClone);
}

let __createTankEnimiesOfLevel = function (levelTank, numberTank, x , y) {
    if (levelTank == 2) {
        levelTank = 3;
    }
    else if (levelTank == 3) {
        levelTank = 6;
    }
    else if (levelTank == 4) {
        levelTank = 12;
    }
    else if (levelTank == 5) {
        levelTank = 24;
    }

    for (let i = 0; i < numberTank; i++) {
        x = x == null ? 1420 : x;
        y = y == null ? 385 : y;
        let tankC = game.add.sprite(x, y, 'tankC');
        tankC.anchor.setTo(0.5, 0.5);
        tankC.angle = -90;
        tankC.scale.setTo(0.8);
        tankC.level = levelTank;
        updateLevel(tankC);
        groupTanksEnimies.add(tankC);
    }
}

let createBossLevel5 = function (x, y) {
    let bossLevel5 = game.add.sprite(x, y, 'bosslevel5');
    bossLevel5.anchor.set(0.5);
    bossLevel5.angle = -90;
    bossLevel5.life = 200;
    bossLevel5.damage = 10;
    bossLevel5.speedFire = 400;
    bossLevel5.delayFire = 300;
    groupBossLevel5.add(bossLevel5);

    bossLevel5.nhamTank = tank1;

    let intervalId = game.time.events.loop(1500, function() {
        if (bossLevel5.body) {
            let rdF = Math.floor((Math.random() * 2) + 1);
            bossLevel5.nhamTank = rdF == 1 ? (tank1.body ? tank1 : tank2) : (tank2.body ? tank2 : tank1);
        }
        else {
            game.time.events.remove(intervalId);
        }
    }, this);
}

let createBossLevel10 = function (x, y) {
    let bossLevel10 = game.add.sprite(x, y, 'bosslevel10');
    bossLevel10.anchor.set(0.5);
    bossLevel10.angle = -90;
    bossLevel10.life = 700;
    bossLevel10.damage = 10;
    bossLevel10.speedFire = 400;
    bossLevel10.delayFire = 300;
    groupBossLevel10.add(bossLevel10);

    let intervalId = game.time.events.loop(4000, ()=>{
        if (bossLevel10.body) {
            if (groupTanksEnimies.children.length < 70) {
                let rdF = Math.floor((Math.random() * 5) + 4);
                let slTankC = bossLevel10.life > 300 ? 5 : bossLevel10.life > 100 ? 9 : 14;
                __createTankEnimiesOfLevel(rdF, rdF == 5 ? Math.floor(slTankC/3) : slTankC, 1300 , 385);
                groupTanksEnimies.forEach(tankC => {
                    fireComputer(tankC);
                    computerFindPlayers(tankC);
                });
                game.physics.enable(groupTanksEnimies, Phaser.Physics.ARCADE);
            }
        }
        else {
            game.time.events.remove(intervalId);
        }
    }, this);
}

let createLaser = function (tank) {
    if (!tank.khoaLaser & gameStart & tank.level > 12) {
        tank.khoaLaser = true;
        tank.body.moves = false;
        let laser = game.add.sprite(tank.x, tank.y, 'laser');
        let laser_ = game.add.sprite(tank.x, tank.y, 'laser');
        laser_.alpha = 0;
        laser.anchor.set(0.5);
        laser_.anchor.set(0.5);
        laser.scale.setTo(30, 0.1);
        laser_.scale.setTo(30, 0.1);
        if (tank.angle == 90) {
            laser.angle = 0;
            laser.x = laser.x + laser.width / 2 + tank.width;
            laser_.x = laser_.x + laser_.width / 2;
        }
        else if (tank.angle == -90) {
            laser.angle = 180;
            laser.x = laser.x - laser.width / 2 - tank.width;
            laser_.x = laser_.x - laser_.width / 2;
        }
        else if (tank.angle == 0) {
            laser.angle = -90;
            laser.y = laser.y - laser.width / 2 - tank.height;
            laser_.scale.setTo(0.1, 30);
            laser_.y = laser_.y - laser_.height / 2
        }
        else if (tank.angle == -180) {
            laser.angle = 90;
            laser.y = laser.y + laser.width / 2 + tank.height;
            laser_.scale.setTo(0.1, 30);
            laser_.y = laser_.y + laser_.height / 2
        }
        laser.tank = tank.key;

        laser_.fireDamage = 1.55;
        groupLasers.add(laser_);
        game.physics.enable(groupLasers, Phaser.Physics.ARCADE);


        laserFire(laser, laser_, tank);
        let timeout = game.time.events.add(30000, function () {
            tank.khoaLaser = false;
            game.time.events.remove(timeout);
        });
    }
}

let createEnergyShield = function (tank) {
    let haveTank = tank.key == 'tank1' ? tank1.body : (tank.key == 'tank2' ? tank2.body : tank.body);
    if (!tank.khoaShield & gameStart & haveTank != null) {
        tank.khoaShield = true;
        tank.battu = true;
        let energyShield = game.add.sprite(tank1.x, tank1.y, 'energyShield');
        energyShield.anchor.set(0.5);
        energyShield.tank = tank.key;
        groupShields.add(energyShield);
        game.physics.enable(groupShields, Phaser.Physics.ARCADE);
        let timeout = game.time.events.add(10000, function () {
            energyShield.destroy();
            tank.battu = false;
            game.time.events.remove(timeout);
            let timeout2 = game.time.events.add(7000, function () {
                energyShield = undefined;
                tank.khoaShield = false;
                game.time.events.remove(timeout2);
            });
        });
    }
}