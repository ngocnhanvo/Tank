let isMobile = {
    Android: function () {
        return navigator.userAgent.match(/Android/i);
    },
    BlackBerry: function () {
        return navigator.userAgent.match(/BlackBerry/i);
    },
    iOS: function () {
        return navigator.userAgent.match(/iPhone|iPad|iPod/i);
    },
    Opera: function () {
        return navigator.userAgent.match(/Opera Mini/i);
    },
    Windows: function () {
        return navigator.userAgent.match(/IEMobile/i) || navigator.userAgent.match(/WPDesktop/i);
    },
    any: function () {
        return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows());
    }
};

let config = {
    width: window.innerWidth,
    height: window.innerHeight,
    renderer: Phaser.CANVAS,
    parent: 'Battle city',
    version: "0.0.1",
    transparent: false,
    antialias: false,
    state: this,
    scaleMode: Phaser.ScaleManager.EXACT_FIT,
    fps: 10
};

let createGameMBDT = function () {
    if (isMobile.any()) {
        config.width = window.innerWidth * 1.25;
        config.height = window.innerHeight * 1.25;
        //$('.zonePad').removeClass('hidden');
        $('.zonePadButton').removeClass('hidden');
    }
    else {
        $('body').css('zoom', '');
        config.width = window.innerWidth;
        config.height = window.innerHeight;
    }
};


createGameMBDT();
let game = new Phaser.Game(config);
window.onresize = function () {
    if(confirm('Reload to scale screen')) {
        window.location.href = '';
    }
};

function preload() {
    if (isMobile.any())
        $('canvas').css('zoom', '0.8');

    game.load.tilemap('map', 'assets/tilemaps/json/level_001.json?' + uuidv4(), null, Phaser.Tilemap.TILED_JSON);
    game.load.image('ground_1x1', 'assets/tilemaps/tiles/ground_1x1.png');
    game.load.image('vnn_co', 'assets/tilemaps/tiles/vnn_co.png');
    game.load.image('bosslevel5', 'assets/tanks/boss-level5.png');
    game.load.image('bosslevel10', 'assets/tanks/boss-level10.png');
    game.load.image('bosslevel5Dan', 'assets/tanks/boss-level5_dan.png');
    game.load.image('tank1Died', 'assets/tanks/p1-died.png');
    game.load.image('tank2Died', 'assets/tanks/p2-died.png');
    game.load.image('boom', 'assets/tanks/boom_level001.png');
    game.load.image('boomEnd', 'assets/tanks/boom_level002.png');
    game.load.image('portal', 'assets/tanks/portal.png');
    game.load.image('itemLevelUp', 'assets/tanks/items/levelup.png');
    game.load.image('energyShield', 'assets/tanks/energyShield.png');
    game.load.image('laser', 'assets/tanks/laser.png');
    game.load.image('gamePadVNN', 'assets/virtualjoystick/gamePadVNN.png');

    game.load.bitmapFont('desyrel', 'assets/fonts/bitmapFonts/desyrel.png', 'assets/fonts/bitmapFonts/desyrel.xml');

    game.load.audio("tankRun", "assets/mp3/TankRun.mp3");
    game.load.audio("tankFire", "assets/mp3/TankFire.mp3");
    game.load.audio("tankBoom", "assets/mp3/TankBoom.mp3");
    game.load.audio("tankOpen", "assets/mp3/TankOpen.mp3");

    game.load.spritesheet('ms', 'assets/tilemaps/tiles/vnn.png', 32, 32, 2);
    game.load.spritesheet('tank1', 'assets/tanks/p1-tanks.png?' + uuidv4(), 42, 43);
    game.load.spritesheet('tank2', 'assets/tanks/p2-tanks.png?' + uuidv4(), 42, 43);
    game.load.spritesheet('tankC', 'assets/tanks/pC-tanks.png?' + uuidv4(), 42, 43);
    if (isMobile.any())
        this.load.spritesheet('gamepad', 'assets/virtualjoystick/gamepad_spritesheet.png', 100, 100);
}

function create() {
    keyboards = game.input.keyboard;
    textGamePause = createBitMapText(70, 'GAME PAUSE\n press "P" to resume', 64);
    textGamePause.fontSize = textGamePause.fontSize + 15;
    textLevel = createBitMapText(50, 'LEVEL ' + levelMap, 80);
    let txt = "R";
    if (isMobile.any())
        txt = "C";
    textGameOver = createBitMapText(70, 'GAME OVER\n press "'+ txt +'" to try again', 64);
    textGameOver.fontSize = textGameOver.fontSize + 15;

    music.tankRun = game.add.audio('tankRun');
    music.tankRun.volume = 0.2;
    music.tankFire = game.add.audio('tankFire');
    music.tankFire.volume = 0.1;
    music.tankBoom = game.add.audio('tankBoom');
    music.tankBoom.volume = 0.4;
    music.tankOpen = game.add.audio('tankOpen');
    music.tankOpen.volume = 1;
    hideLoading();

    if (isMobile.any()) {
        this.gamepad = game.plugins.add(Phaser.Plugin.VirtualGamepad);
        stickDpad = this.gamepad.addJoystick(80, window.innerHeight - 70, 1.25, 'gamepad');
        stickDpad.alpha = 0;
        this.gamepad.joystickPad.alpha = 0;
        this.button = this.gamepad.addButton(-10000, -10000, 1.0, 'gamepad');
        stickDpadClone = game.add.sprite(0, 0, "gamePadVNN");
        stickDpadClone.width = 124*1.25;
        stickDpadClone.height = 124*1.25;
        stickDpadClone.alpha = 0.7;
        $('#okGame').click();
    }
}

function update() {
    let body1, body2;
    try {
        if (isMobile.any()) {
            if(stickDpadClone) {
                stickDpadClone.x = game.camera.x + 24;
                stickDpadClone.y = game.camera.y + config.height - 164;
            }
        }

        if (portalNext)
            portalNext.angle += 1;
        if (gameStart == true) {

            body1 = tank1 ? tank1.body : null;
            body2 = tank2 ? tank2.body : null;
            if (!body1 & !body2 & !textGameOver.visible) {
                if (groupTanksEnimies) {
                    textGameOver.visible = true;
                    textGameOver.y = game.camera.y + config.height / 2;
                    textGameOver.x = game.camera.x + config.width / 2;
                }
            }
            else if (groupTanksEnimies) {
                if (groupTanksEnimies.children.length <= 0) {
                    portalNext.alpha = 1;
                }
                else {
                    portalNext.alpha = 0;
                }

                tank1InPortal = tank1.body ? false : true;
                tank2InPortal = tank2.body ? false : true;
                if (tank1InPortal & tank2InPortal) {
                    tank1InPortal = tank2InPortal = false;
                }

                game.physics.arcade.overlap(portalSquare, groupTanks, function (portal, tank) {
                    if (portalNext.alpha == 1) {
                        if (rectContainsRect(portal.getBounds(), tank.getBounds())) {
                            if (tank.key == 'tank1') {
                                tank1InPortal = true;
                            }
                            else if (tank.key == 'tank2') {
                                tank2InPortal = true;
                            }
                        }
                    }
                });

                if (tank1InPortal == true) {
                    //tank1.visible = false;
                    if (tank1.body) {
                        tank1.body.moves = false;
                    }
                    game.add.tween(tank1).to({ alpha: 0 }, 200, Phaser.Easing.Linear.None, true);
                }

                if (tank2InPortal == true) {
                    //tank1.visible = false;
                    if (tank2.body) {
                        tank2.body.moves = false;
                    }
                    game.add.tween(tank2).to({ alpha: 0 }, 200, Phaser.Easing.Linear.None, true);
                }

                if (tank1InPortal & tank2InPortal) {
                    if (tank1.alpha < 0.01 & tank2.alpha < 0.01) {
                        levelMap++;
                        createLevel();
                    }
                }

                if (!tank1InPortal & !tank2InPortal)
                    game.physics.arcade.collide(groupTanks, groupTanks);

                // game.physics.arcade.collide(groupTanksEnimies, groupTanksEnimies, function (tank) {
                //     tank.autoMove = 3;
                //     movesComputer(tank);
                // }, null);

                game.physics.arcade.collide(groupTanks, groupTanksEnimies);
                game.physics.arcade.overlap(groupTanks, groupBossLevel5, function (tank, boss) {
                    preventThroupWalls(tank, boss);
                });

                game.physics.arcade.overlap(groupTanks, groupBossLevel10, function (tank, boss) {
                    preventThroupWalls(tank, boss);
                });

                game.physics.arcade.overlap(groupTanksEnimies, groupShields, function (tank, shield) {
                    preventThroupWalls(tank, shield);
                });

                game.physics.arcade.collide(groupTanks, layer0);
                game.physics.arcade.collide(groupTanksEnimies, layer0);
                game.physics.arcade.collide(groupFireTanks, layer0);
                game.physics.arcade.collide(groupFireTanksEnimies, layer0);
                game.physics.arcade.collide(groupBossLevel5Dan, layer0);

                game.physics.arcade.collide(groupTanks, layer);
                game.physics.arcade.collide(groupTanksEnimies, layer);
                game.physics.arcade.collide(groupFireTanks, layer);
                game.physics.arcade.collide(groupFireTanksEnimies, layer);

                game.physics.arcade.overlap(groupFireTanks, groupTanksEnimies, function (fire, tank) {
                    if (fire.dan)
                        fireBetweenTanks(fire, tank);
                }, null);

                game.physics.arcade.overlap(groupFireTanksEnimies, groupTanks, function (fire, tank) {
                    if (fire.dan)
                        fireBetweenTanks(fire, tank);
                }, null);

                game.physics.arcade.overlap(groupBossLevel5Dan, groupTanks, function (fire, tank) {
                    if (tank) {
                        if (fire.danBossLevel5) {
                            fireBetweenTanks(fire, tank);
                        }
                    }
                }, null);

                game.physics.arcade.overlap(groupFireTanks, groupBossLevel5, function (fire, tank) {
                    if (tank) {
                        if (fire.dan) {
                            fireBetweenTanks(fire, tank);
                        }
                    }
                }, null);

                game.physics.arcade.overlap(groupFireTanks, groupBossLevel10, function (fire, tank) {
                    if (tank) {
                        if (fire.dan) {
                            fireBetweenTanks(fire, tank);
                        }
                    }
                }, null);

                game.physics.arcade.overlap(groupLasers, groupTanksEnimies, function (fire, tank) {
                    if (tank) {
                        fireBetweenTanks(fire, tank);
                    }
                }, null);

                game.physics.arcade.overlap(groupLasers, groupFireTanksEnimies, function (fire, fireEnimy) {
                    if (fireEnimy) {
                        boomLevelNormal(fireEnimy);
                    }
                }, null);

                game.physics.arcade.overlap(groupLasers, groupBossLevel5Dan, function (fire, fireEnimy) {
                    if (fireEnimy) {
                        boomLevel5No(fireEnimy);
                    }
                }, null);

                game.physics.arcade.overlap(groupFireTanks, groupFireTanksEnimies, function (fire, fireEnimy) {
                    let fireD = fire.fireDamage, fireED = fireEnimy.fireDamage;
                    fire.fireDamage -= fireED;
                    fireEnimy.fireDamage -= fireD;
                    if (fire.fireDamage <= 0 & fire.dan)
                        boomLevelNormal(fire);
                    if (fireEnimy.fireDamage <= 0 & fireEnimy.dan)
                        boomLevelNormal(fireEnimy);
                }, null);

                game.physics.arcade.overlap(groupItems, groupTanks, function (item, tank) {
                    if (item.roido == 5) {
                        item.roido = 0;
                        updateLevel(tank, true);
                        item.destroy();
                    }
                }, null, this);

                groupTanks.forEach(tank => {
                    tank.body.angularAcceleration = 0;
                    tank.body.velocity.x = 0;
                    tank.body.velocity.y = 0;
                    if (tank.anthan) {
                        tank.alpha = 0.5;
                    }
                    else
                        tank.alpha = 1;

                    if (!tank.prevPosStop) {
                        tank.xprev = tank.x;
                        tank.yprev = tank.y;
                    }

                    UpDownLeftRight(tank);
                });

                groupTanksEnimies.forEach(tank => {
                    tank.body.angularAcceleration = 0;
                    tank.body.velocity.x = 0;
                    tank.body.velocity.y = 0;
                    if (tank.anthan) {
                        tank.alpha = 0;
                    }
                    else
                        tank.alpha = 1;

                    if (tank.autoMove == 1) {
                        if (tank1.body) {
                            findPathToPlayer(tank, tank1);
                        }
                        else if (tank2.body) {
                            findPathToPlayer(tank, tank2);
                        }
                    }
                    else if (tank.autoMove == 2) {
                        if (tank2.body) {
                            findPathToPlayer(tank, tank2);
                        }
                        else if (tank1.body) {
                            findPathToPlayer(tank, tank1);
                        }
                    }

                    if (!tank.prevPosStop) {
                        tank.xprev = tank.x;
                        tank.yprev = tank.y;
                    }

                    UpDownLeftRightEnimies(tank);
                });

                groupTanks.forEach(tank => {
                    tank.anthan = false;
                });

                groupTanksEnimies.forEach(tank => {
                    tank.anthan = false;
                });
            }

            groupBossLevel5.forEach(bossLevel5 => {
                if (bossLevel5.body)
                    bossLevel5.rotation = game.physics.arcade.angleBetween(bossLevel5, bossLevel5.nhamTank) + 1.6;
            });

            groupShields.forEach(shield => {
                let tank = shield.tank == 'tank1' ? tank1 : tank2;
                shield.x = tank.x;
                shield.y = tank.y;
            });

            game.physics.arcade.overlap(groupShields, groupFireTanksEnimies, function (shield, fireEnimy) {
                fireEnimy.fireDamage = 0;
                if (fireEnimy.fireDamage <= 0 & fireEnimy.dan)
                    boomLevelNormal(fireEnimy);
            }, null);

            game.physics.arcade.overlap(groupShields, groupBossLevel5Dan, function (shield, fireEnimy) {
                fireEnimy.fireDamage = 0;
                if (fireEnimy.fireDamage <= 0 & fireEnimy.danBossLevel5)
                    boomLevel5No(fireEnimy);
            }, null);

            keepCamera2Players(tank1.body, tank2.body);
        }
    }
    catch (r) {
        try {
            keepCamera2Players(tank1.body, tank2.body);
        }
        catch(rr) { }
    }
}

function render() {

}
