//#region avariable
let gameHeight = window.innerHeight;
let gameWidth = window.innerWidth;
let map, layer0, layer, tank1, tank2, gameStart;
let tank1Died, tank2Died, energyShield1, energyShield2, laser2, laser2_;
let cameraFollow, tank1Run, stickDpad, stickDpadClone;

let groupTanks;
let groupTanksEnimies;
let groupTanksBoss;
let groupBossLevel5, groupBossLevel5Dan;
let groupBossLevel10, groupBossLevel10Dan;

let groupFireTanks;
let groupFireTanksEnimies;
let groupBringToTop;
let groupItems;
let groupWaters;
let groupShields, groupLasers;
let levelMap = 1;
let levelMax = 10;
let tank1InPortal, tank2InPortal;
let portalNext, portalSquare;
let textGamePause = null;
let textLevel = null;
let textGameOver = null;
let textYouWin = null;
let keyboards = null;
let player1Enable, player1EnSav, player2Enable, player2EnSav;
player1Enable = player2Enable = player1EnSav = player2EnSav = false;

let music = {};
let arrTyLe = [];
for (let iii = 0; iii < 100; iii++) {
    arrTyLe[iii] = 0;
}

let keyboardPlayer1 = {
    up: null,
    keepUp: false,
    firstKU: false,
    stopUp: false,
    down: null,
    keepDown: false,
    firstKD: false,
    stopDown: false,
    left: null,
    keepLeft: false,
    firstKL: false,
    stopLeft: false,
    right: null,
    keepRight: false,
    firstKR: false,
    stopRight: false,
    fire: null,
    startFire: false,
    delayFire: 1000,
    special: null,
    speed: 120,
    life: 1,
    damage: 1,
    level: 0,
    speedFire: 200,
    themmau: 1.5
};
let keyboardPlayer2 = { ...keyboardPlayer1 };
let kbroot1 = { ...keyboardPlayer1 };
let kbroot2 = { ...keyboardPlayer2 };
let keyboardPlayer1BK, keyboardPlayer2BK;
let keyboardEnimies = {
    speed: 100,
    life: 1,
    delayFire: 2000,
    damage: 1,
    level: 0,
    themmau: 1
};
keyboardEnimies.speedFire = 180;

let DownUpPress = function (kbp, tank) {
    let prioty = 0;
    let upEvent1 = function () {
        kbp.keepUp = true;
        prioty++;
        kbp.upPrioty = prioty;
    }

    let upEvent2 = function () {
        kbp.keepUp = false;
        kbp.firstKU = false;
        kbp.upPrioty = 0;
    }

    let downEvent1 = function () {
        kbp.keepDown = true;
        prioty++;
        kbp.downPrioty = prioty;
    }

    let downEvent2 = function () {
        kbp.keepDown = false;
        kbp.firstKD = false;
        kbp.downPrioty = 0;
    }

    let leftEvent1 = function () {
        kbp.keepLeft = true;
        prioty++;
        kbp.leftPrioty = prioty;
    }

    let leftEvent2 = function () {
        kbp.keepLeft = false;
        kbp.firstKL = false;
        kbp.leftPrioty = 0;
    }

    let rightEvent1 = function () {
        kbp.keepRight = true;
        prioty++;
        kbp.rightPrioty = prioty;
    }

    let rightEvent2 = function () {
        kbp.keepRight = false;
        kbp.firstKR = false;
        kbp.rightPrioty = 0;
    }

    let fireEvent1 = function () {
        if (kbp.startFire == false) {
            tank = tank.key == 'tank1' ? tank1 : tank2;
            createFire(tank);
            kbp.startFire = true;
            let timeout = game.time.events.add(kbp.delayFire, function() {
                kbp.startFire = false;
                game.time.events.remove(timeout);
            });
        }
    }

    kbp.up.onDown.add(() => {
        upEvent1();
    }, this);
    kbp.up.onUp.add(() => {
        upEvent2();
    }, this);

    kbp.down.onDown.add(() => {
        downEvent1();
    }, this);
    kbp.down.onUp.add(() => {
        downEvent2();
    }, this);

    kbp.left.onDown.add(() => {
        leftEvent1();
    }, this);
    kbp.left.onUp.add(() => {
        leftEvent2();
    }, this);

    kbp.right.onDown.add(() => {
        rightEvent1();
    }, this);
    kbp.right.onUp.add(() => {
        rightEvent2();
    }, this);

    kbp.fire.onDown.add(() => {
        fireEvent1();
    }, this);
    let fireGamePad = $('.fireGamePad');
    //rightGamePad.off('touchstart');
    fireGamePad.on('touchstart', function () {
        fireEvent1();
    });

    let shieldGamePad = $('.shieldGamePad');
    //shieldGamePad.off('touchstart');
    shieldGamePad.on('touchstart', function () {
        createEnergyShield(tank);
    });

    let laserGamePad = $('.laserGamePad');
    //laserGamePad.off('touchstart');
    laserGamePad.on('touchstart', function () {
        createLaser(tank);
        restartGameTank();
    });
}
//#endregion avariable