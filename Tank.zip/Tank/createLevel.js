let createLevel = function () {
    gameStart = false;
    keyboards.reset();
    if (levelMap > levelMax) {
        if (textYouWin == null) {
            textYouWin = createBitMapText(0, 'YOU WIN', 100);
            textYouWin.visible = true;
        }
        return;
    }
    else {
        music.tankOpen.play();
    }
    if (map)
        map.destroy();
    if (layer)
        layer.destroy();
    if (layer0)
        layer0.destroy();

    player1Enable = player1EnSav;
    player2Enable = player2EnSav;
    if (tank1)
        tank1.destroy();
    if (tank2)
        tank2.destroy();

    map = game.add.tilemap('map');
    map.addTilesetImage('ground_1x1');
    map.addTilesetImage('vnn_co');
    if (tank1Died)
        tank1Died.destroy();
    tank1Died = game.add.sprite(0, 0, 'tank1Died');
    tank1Died.visible = false;

    if (tank2Died)
        tank2Died.destroy();
    tank2Died = game.add.sprite(0, 0, 'tank2Died');
    tank2Died.visible = false;

    layer0 = map.createLayer('Tile Layer 0');
    layer0.debug = false;
    layer0.resizeWorld();

    layer = map.createLayer('Tile Layer ' + levelMap);
    layer.debug = false;
    layer.resizeWorld();

    map.setTileIndexCallback(1, function (sprite, tile) {
        if (sprite.dan == true) {
            if (tile.alpha != 0) {
                boomLevelNormal(sprite);
            }
        }
        else if (sprite.danBossLevel5 == true) {
            if (tile.alpha != 0) {
                boomLevel5No(sprite);
            }
        }
        else if (sprite.key.toString().lastIndexOf('tank') > -1) {
            preventThroupWalls(sprite, tile);
        }
    }, game, layer0);

    map.setTileIndexCallback(3, function (sprite, tile) {
        if (sprite.dan) {
            tileCanRemove(sprite, tile, 2, map);
        }
        else if (sprite.key.toString().lastIndexOf('tank') > -1) {
            let kbp = getKeyBoard(sprite);
            if (kbp.level >= 12) {
                removeTile(tile, map);
            }
            else {
                preventThroupWalls(sprite, tile);
            }
        }
    }, game, layer);

    map.setTileIndexCallback(22, function (sprite, tile) {
        if (sprite.dan) {
            tileCanRemove(sprite, tile, 100, map);
        }
        else if (sprite.danBossLevel5) {

        }
        else if (sprite.key.toString().lastIndexOf('tank') > -1) {
            preventThroupWalls(sprite, tile);
        }
    }, game, layer0);

    map.setTileIndexCallback(22, function (sprite, tile) {
        if (sprite.dan) {
            tileCanRemove(sprite, tile, 100, map);
        }
        else if (sprite.key.toString().lastIndexOf('tank') > -1) {
            preventThroupWalls(sprite, tile);
        }
    }, game, layer);

    map.setTileIndexCallback(196, function (sprite, tile) {
        if (sprite.dan) {
            let kbp = getKeyBoard(sprite);
            if (kbp.level >= 24) {
                removeTile(tile, map);
            }
        }
        else if (sprite.key.toString().lastIndexOf('tank') > -1) {
            if (tile.alpha != 0)
                sprite.anthan = true;
        }
    }, game, layer);

    map.setTileIndexCallback(197, function (sprite, tile) {
        if (sprite.key.toString().lastIndexOf('tank') > -1) {
            if (sprite.level < 24) {
                preventThroupWalls(sprite, tile);
            }
        }
    }, game, layer);

    if (groupWaters)
        groupWaters.destroy();
    groupWaters = game.add.group();
    let tiles = layer.getTiles(0, 0, layer.layer.widthInPixels, layer.layer.heightInPixels);
    tiles = tiles.filter(val => {
        return val.index == 197
    });
    tiles.forEach(tile => {
        let sprite = game.add.sprite(tile.worldX, tile.worldY, 'ms');
        sprite.animations.add('walk');
        sprite.animations.play('walk', 1, true);
        groupWaters.add(sprite);
    });

    //Items
    if (groupItems)
        groupItems.destroy();
    groupItems = game.add.group();

    //Players
    if (groupTanks)
        groupTanks.destroy();
    groupTanks = game.add.group();
    createPlayer1(keyboards);
    createPlayer2(keyboards);
    game.physics.enable(groupTanks, Phaser.Physics.ARCADE);

    //Enimies
    if (groupBossLevel5)
        groupBossLevel5.destroy();
    groupBossLevel5 = game.add.group();
    if (groupBossLevel5Dan)
        groupBossLevel5Dan.destroy();
    groupBossLevel5Dan = game.add.group();
    if (groupBossLevel10)
        groupBossLevel10.destroy();
    groupBossLevel10 = game.add.group();
    if (groupBossLevel10Dan)
        groupBossLevel10Dan.destroy();
    groupBossLevel10Dan = game.add.group();
    if (groupTanksBoss)
        groupTanksBoss.destroy();
    groupTanksBoss = game.add.group();
    if (groupTanksEnimies)
        groupTanksEnimies.destroy();
    groupTanksEnimies = game.add.group();
    if (groupShields)
        groupShields.destroy();
    groupShields = game.add.group();
    if (groupLasers)
        groupLasers.destroy();
    groupLasers = game.add.group();
    createTankEnimiesOfLevel(levelMap);
    //Fire Tanks
    if (groupFireTanks)
        groupFireTanks.destroy();
    groupFireTanks = game.add.group();
    //Fire Enimies
    if (groupFireTanksEnimies)
        groupFireTanksEnimies.destroy();
    groupFireTanksEnimies = game.add.group();

    game.world.bringToTop(textLevel);
    game.world.bringToTop(textGameOver);
    game.world.bringToTop(textGamePause);

    keyboardPlayer1.keepDown = keyboardPlayer1.keepLeft = keyboardPlayer1.keepRight = keyboardPlayer1.keepUp = false;
    keyboardPlayer2.keepDown = keyboardPlayer2.keepLeft = keyboardPlayer2.keepRight = keyboardPlayer2.keepUp = false;

    game.time.events.add(500, function () {
        textLevel.text = "LEVEL " + levelMap;
        textLevel.fontSize = 80;
        textLevel.anchor.set(0.5);
        textLevel.align = 'center';
        textLevel.y = game.camera.y + config.height / 2;
        textLevel.x = game.camera.x + config.width / 2;
        let timeStart = 3;
        textLevel.visible = true;
        textLevel.alpha = 1;
        let intervalId = game.time.events.loop(1000, function () {
            textLevel.text = timeStart;
            textLevel.fontSize = 150;
            textLevel.anchor.set(0.5);
            textLevel.align = 'center';
            timeStart--;
            if (timeStart == 0) {
                game.time.events.remove(intervalId);
                game.add.tween(textLevel).to({ alpha: 0 }, 1500, Phaser.Easing.Linear.None, true);
                let timeout = game.time.events.add(1000, function () {
                    gameStart = true;
                    game.time.events.remove(timeout);
                });
            }
        });
    });

    if (!portalNext) {
        portalNext = game.add.sprite(1650, 380, 'portal');
        portalSquare = game.add.sprite(1650, 380, 'portal');
        portalNext.anchor.set(0.5);
        portalSquare.anchor.set(0.5);
        portalSquare.alpha = 0;
        game.world.sendToBack(portalNext);
        game.physics.enable(portalSquare, Phaser.Physics.ARCADE);
    }
    portalNext.alpha = 0;

    DownUpPress(keyboardPlayer1, tank1);
    DownUpPress(keyboardPlayer2, tank2);
    keepCamera2Players(tank1.body, tank2.body);
}

let restartGameTank = function() {
    if (textGameOver.visible) {
        resetAfterDied(keyboardPlayer1, keyboardPlayer1BK);
        resetAfterDied(keyboardPlayer2, keyboardPlayer2BK);
        textGameOver.visible = false;
        player1Enable = player1EnSav;
        player2Enable = player2EnSav;
        createLevel();
    }
}

let createPlayer1 = function (keyboards) {
    if (tank1)
        tank1.destroy();
    tank1 = game.add.sprite(50, 360, 'tank1');
    tank1.anchor.setTo(0.5, 0.5);
    tank1.angle = 90;
    tank1.scale.setTo(0.8);
    updateLevel(tank1);
    let kbp1 = keyboardPlayer1;
    tankReceivedItems(tank1, kbp1);
    groupTanks.add(tank1);

    kbp1.leftPrioty = kbp1.rightPrioty = kbp1.upPrioty = kbp1.downPrioty = 0;
    kbp1.up = keyboards.addKey(Phaser.Keyboard.W);
    kbp1.down = keyboards.addKey(Phaser.Keyboard.S);
    kbp1.left = keyboards.addKey(Phaser.Keyboard.A);
    kbp1.right = keyboards.addKey(Phaser.Keyboard.D);
    kbp1.fire = keyboards.addKey(Phaser.Keyboard.F);
    kbp1.shield = keyboards.addKey(Phaser.Keyboard.G);
    kbp1.shield.onDown.add(() => {
        createEnergyShield(tank1);
    }, this);

    kbp1.laser = keyboards.addKey(Phaser.Keyboard.H);
    kbp1.laser.onDown.add(() => {
        createLaser(tank1);
    }, this);

    kbp1.pauseGame = keyboards.addKey(Phaser.Keyboard.P);
    kbp1.pauseGame.onDown.add(() => {
        if (gameStart & !textGameOver.visible) {
            game.paused = !game.paused;
            textGamePause.visible = !textGamePause.visible;
        }
    }, this);

    kbp1.restart = keyboards.addKey(Phaser.Keyboard.R);
    kbp1.restart.onDown.add(() => {
        restartGameTank();
    }, this);

    if (!player1Enable)
        tank1.destroy();

    keyboardPlayer1BK = Object.assign({}, keyboardPlayer1);
}

createPlayer2 = function (keyboards) {
    if (tank2)
        tank2.destroy();
    tank2 = game.add.sprite(50, 400, 'tank2');
    tank2.anchor.setTo(0.5, 0.5);
    tank2.angle = 90;
    tank2.scale.setTo(0.8);
    updateLevel(tank2);
    let kbp2 = keyboardPlayer2;
    tankReceivedItems(tank2, kbp2);
    groupTanks.add(tank2);

    kbp2.leftPrioty = kbp2.rightPrioty = kbp2.upPrioty = kbp2.downPrioty = 0;
    kbp2.up = keyboards.addKey(Phaser.Keyboard.UP);
    kbp2.down = keyboards.addKey(Phaser.Keyboard.DOWN);
    kbp2.left = keyboards.addKey(Phaser.Keyboard.LEFT);
    kbp2.right = keyboards.addKey(Phaser.Keyboard.RIGHT);
    kbp2.fire = keyboards.addKey(Phaser.Keyboard.NUMPAD_1);
    kbp2.shield = keyboards.addKey(Phaser.Keyboard.NUMPAD_2);
    kbp2.shield.onDown.add(() => {
        createEnergyShield(tank2);
    }, this);
    kbp2.laser = keyboards.addKey(Phaser.Keyboard.NUMPAD_3);
    kbp2.laser.onDown.add(() => {
        createLaser(tank2);
    }, this);

    if (!player2Enable)
        tank2.destroy();

    keyboardPlayer2BK = Object.assign({}, keyboardPlayer2);
}