<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="level_001" tilewidth="10" tileheight="10" tilecount="10640" columns="140">
 <image source="../../../../../images/maps/level_001.png" width="1400" height="768"/>
</tileset>
