let removeTile = function (tile, map) {
    tile.alpha = 0;
    tile.collideUp = false;
    tile.collideDown = false;
    tile.collideLeft = false;
    tile.collideRight = false;
    tile.layer.dirty = true;
    map.dirty = true;
}

let tileCanRemove = function (sprite, tile, mau, map) {
    if (tile.alpha == 1)
        boomLevelNormal(sprite);
    if (!tile.mau) {
        tile.mau = mau;
    }

    tile.mau = tile.mau - sprite.fireDamage;

    if (tile.mau <= 0) {
        removeTile(tile, map);
    }
}

let rectContainsPoint = function (rect, x, y) {
    let ok = false;
    if (x >= rect.x & x <= rect.x + rect.width & y >= rect.y & y <= rect.y + rect.height) {
        ok = true;
    }
    return ok;
}

let rectContainsRect = function (rect, rect2) {
    let ok = false, next1 = false, next2 = false;
    if (rectContainsPoint(rect, rect2.x, rect2.y)) {
        next1 = true;
    }

    if (rectContainsPoint(rect, rect2.x + rect2.width, rect2.y + rect2.height)) {
        next2 = true;
    }

    ok = next1 & next2 ? true : false;
    return ok;
}

let createBitMapText = function (maxWidth, content, size) {
    let sprite = game.add.bitmapText(config.width / 2, game.world.centerY, 'desyrel', content, size);
    sprite.y = game.camera.y + config.height / 2;
    sprite.x = game.camera.x + config.width / 2;

    sprite.anchor.set(0.5);
    sprite.align = 'center';
    sprite.visible = false;
    let ssTxtGP = game.width - sprite.width - maxWidth;
    if (ssTxtGP < 0) {
        sprite.maxWidth = game.width;
    }
    return sprite;
}

let checkIsPlayers = function (sprite) {
    return ['tank1', 'tank2'].lastIndexOf(sprite.key) > -1
}

let preventThroupWalls = function (sprite, tile) {
    if (tile.alpha != 0) {
        sprite.prevPosStop = true;
        sprite.x = sprite.xprev;
        sprite.y = sprite.yprev;
        sprite.prevPosStop = false;

        if (!checkIsPlayers(sprite)) {
            sprite.autoMove = 3;
            movesComputer(sprite);
        }
    }
}

//#region function Custom
let checkOverlap = function (spriteA, spriteB) {
    var boundsA = spriteA.getBounds();
    var boundsB = spriteB.getBounds();
    return Phaser.Rectangle.intersects(boundsA, boundsB);
}

let getKeyBoard = function (tank, root) {
    let kbp = null;
    if (tank.key == 'tank1') {
        kbp = root ? kbroot1 : keyboardPlayer1;
    }
    else if (tank.key == 'tank2') {
        kbp = root ? kbroot2 : keyboardPlayer2;
    }
    else if (tank.keyTank == 'tank1') {
        kbp = root ? kbroot1 : keyboardPlayer1;
    }
    else if (tank.keyTank == 'tank2') {
        kbp = root ? kbroot2 : keyboardPlayer2;
    }
    else {
        kbp = keyboardEnimies;
    }
    return kbp;
}

let UpDownLeftRight = function (tank) {

    let kbp = getKeyBoard(tank);
    if (tank.body) {
        if (isMobile.any()) {
            if (gameStart) {
                if (stickDpad.properties.inUse) {
                    kbp.keepLeft = kbp.keepRight = kbp.keepDown = kbp.keepUp = false;
                    if (stickDpad.properties.left & stickDpad.properties.up) {
                        kbp.upPrioty = kbp.downPrioty = kbp.leftPrioty = kbp.rightPrioty = 0;
                        if (tank.angle == -90) {
                            kbp.leftPrioty = 1;
                            kbp.keepUp = true;
                        }
                        else {
                            kbp.upPrioty = 1;
                            kbp.keepLeft = true;
                        }
                    }
                    else if (stickDpad.properties.left & stickDpad.properties.down) {
                        kbp.upPrioty = kbp.downPrioty = kbp.leftPrioty = kbp.rightPrioty = 0;
                        if (tank.angle == -90) {
                            kbp.leftPrioty = 1;
                            kbp.keepDown = true;
                        }
                        else {
                            kbp.downPrioty = 1;
                            kbp.keepLeft = true;
                        }
                    }
                    else if (stickDpad.properties.right & stickDpad.properties.up) {
                        kbp.upPrioty = kbp.downPrioty = kbp.leftPrioty = kbp.rightPrioty = 0;
                        if (tank.angle == 90) {
                            kbp.rightPrioty = 1;
                            kbp.keepUp = true;
                        }
                        else {
                            kbp.upPrioty = 1;
                            kbp.keepRight = true;
                        }
                    }
                    else if (stickDpad.properties.right & stickDpad.properties.down) {
                        kbp.upPrioty = kbp.downPrioty = kbp.leftPrioty = kbp.rightPrioty = 0;
                        if (tank.angle == 90) {
                            kbp.rightPrioty = 1;
                            kbp.keepDown = true;
                        }
                        else {
                            kbp.downPrioty = 1;
                            kbp.keepRight = true;
                        }
                    }
                    else if (stickDpad.properties.left) {
                        kbp.upPrioty = kbp.downPrioty = kbp.leftPrioty = kbp.rightPrioty = 0;
                        kbp.leftPrioty = 1;
                    }
                    else if (stickDpad.properties.right) {
                        kbp.upPrioty = kbp.downPrioty = kbp.leftPrioty = kbp.rightPrioty = 0;
                        kbp.rightPrioty = 1;
                    }
                    else if (stickDpad.properties.up) {
                        kbp.upPrioty = kbp.downPrioty = kbp.leftPrioty = kbp.rightPrioty = 0;
                        kbp.upPrioty = 1;
                    }
                    else if (stickDpad.properties.down) {
                        kbp.upPrioty = kbp.downPrioty = kbp.leftPrioty = kbp.rightPrioty = 0;
                        kbp.downPrioty = 1;
                    }
                }
                else {
                    kbp.keepLeft = kbp.keepRight = kbp.keepDown = kbp.keepUp = false;
                    kbp.upPrioty = kbp.downPrioty = kbp.leftPrioty = kbp.rightPrioty = 0;
                }
            }
        }

        if (kbp.rightPrioty > kbp.upPrioty
            & kbp.rightPrioty > kbp.downPrioty
            & kbp.rightPrioty > kbp.leftPrioty) {
            tank.angle = 90;
            kbp.keepLeft = false;
            kbp.keepRight = true;
        }
        else if (kbp.leftPrioty > kbp.upPrioty
            & kbp.leftPrioty > kbp.downPrioty
            & kbp.leftPrioty > kbp.rightPrioty) {
            tank.angle = -90;
            kbp.keepLeft = true;
            kbp.keepRight = false;
        }
        else if (kbp.upPrioty > kbp.leftPrioty
            & kbp.upPrioty > kbp.downPrioty
            & kbp.upPrioty > kbp.rightPrioty) {
            tank.angle = 0;
            kbp.keepDown = false;
            kbp.keepUp = true;
        }
        else if (kbp.downPrioty > kbp.upPrioty
            & kbp.downPrioty > kbp.leftPrioty
            & kbp.downPrioty > kbp.rightPrioty) {
            tank.angle = 180;
            kbp.keepDown = true;
            kbp.keepUp = false;
        }

        if (kbp.keepUp & kbp.stopUp == false) {
            if (kbp.firstKU == true)
                tank.body.velocity.y = 0 - kbp.speed;
            else
                kbp.firstKU = true;
        }
        else if (kbp.keepDown & kbp.stopDown == false) {
            if (kbp.firstKD == true)
                tank.body.velocity.y = kbp.speed;
            else
                kbp.firstKD = true;
        }

        if (kbp.keepLeft & kbp.stopLeft == false) {
            if (kbp.firstKL == true)
                tank.body.velocity.x = 0 - kbp.speed;
            else
                kbp.firstKL = true;
        }
        else if (kbp.keepRight & kbp.stopRight == false) {
            if (kbp.firstKR == true)
                tank.body.velocity.x = kbp.speed;
            else
                kbp.firstKR = true;
        }

        if (kbp.keepUp | kbp.keepDown | kbp.keepLeft | kbp.keepRight) {
            switch (tank.frame) {
                case 0: tank.frame = 6; break;
                case 1: tank.frame = 7; break;
                case 2: tank.frame = 8; break;
                case 3: tank.frame = 9; break;
                case 4: tank.frame = 10; break;
                case 5: tank.frame = 11; break;
                case 6: tank.frame = 0; break;
                case 7: tank.frame = 1; break;
                case 8: tank.frame = 2; break;
                case 9: tank.frame = 3; break;
                case 10: tank.frame = 4; break;
                case 11: tank.frame = 5; break;
            }
            music.tankRun.play();
        }
    }
}

let UpDownLeftRightEnimies = function (tank) {
    if (tank) {
        if (tank.keepUp) {
            tank.angle = 0;
            if (tank.firstKU == true)
                tank.body.velocity.y = 0 - tank.speed;
            else
                tank.firstKU = true;
        }
        else if (tank.keepDown) {
            tank.angle = 180;
            if (tank.firstKD == true)
                tank.body.velocity.y = tank.speed;
            else
                tank.firstKD = true;
        }
        else if (tank.keepLeft) {
            tank.angle = -90;
            if (tank.firstKL == true)
                tank.body.velocity.x = 0 - tank.speed;
            else
                tank.firstKL = true;
        }
        else if (tank.keepRight) {
            tank.angle = 90;
            if (tank.firstKR == true)
                tank.body.velocity.x = tank.speed;
            else
                tank.firstKR = true;
        }

        if (tank.keepUp | tank.keepDown | tank.keepLeft | tank.keepRight) {
            switch (tank.frame) {
                case 0: tank.frame = 6; break;
                case 1: tank.frame = 7; break;
                case 2: tank.frame = 8; break;
                case 3: tank.frame = 9; break;
                case 4: tank.frame = 10; break;
                case 5: tank.frame = 11; break;
                case 6: tank.frame = 0; break;
                case 7: tank.frame = 1; break;
                case 8: tank.frame = 2; break;
                case 9: tank.frame = 3; break;
                case 10: tank.frame = 4; break;
                case 11: tank.frame = 5; break;
            }
        }
    }
}

let keepCamera2Players = function (body1, body2) {

    let kbp1 = keyboardPlayer1, kbp2 = keyboardPlayer2;
    if (textYouWin) {
        game.camera.focusOnXY(textYouWin.x, textYouWin.y);
    }
    else if (!body1 & body2 != null) {
        game.camera.focusOnXY(tank2.x, tank2.y);
        cameraFollow = tank2Died;
    }
    else if (!body2 & body1 != null) {
        game.camera.focusOnXY(tank1.x, tank1.y);
        cameraFollow = tank1Died;
    }
    else if (body1 != null & body2 != null) {

        let medianX = (tank1.body.x > tank2.body.x) ? tank1.body.x - (tank1.body.x - tank2.body.x) / 2 : tank2.body.x - (tank2.body.x - tank1.body.x) / 2;
        let medianY = (tank1.body.y > tank2.body.y) ? tank1.body.y - (tank1.body.y - tank2.body.y) / 2 : tank2.body.y - (tank2.body.y - tank1.body.y) / 2;
        game.camera.focusOnXY(medianX, medianY);

        if (tank1.body.x < game.camera.view.x) {
            kbp1.stopLeft = true;
        }
        else {
            kbp1.stopLeft = false;
        }

        if (tank2.body.x < game.camera.view.x) {
            kbp2.stopLeft = true;
        }
        else {
            kbp2.stopLeft = false;
        }

        if (tank1.body.y < game.camera.view.y) {
            kbp1.stopUp = true;
        }
        else {
            kbp1.stopUp = false;
        }

        if (tank2.body.y < game.camera.view.y) {
            kbp2.stopUp = true;
        }
        else {
            kbp2.stopUp = false;
        }

        if (tank1.body.right > game.camera.view.right) {
            kbp1.stopRight = true;
        }
        else {
            kbp1.stopRight = false;
        }

        if (tank2.body.right > game.camera.view.right) {
            kbp2.stopRight = true;
        }
        else {
            kbp2.stopRight = false;
        }

        if (tank1.body.bottom > game.camera.view.bottom) {
            kbp1.stopDown = true;
        }
        else {
            kbp1.stopDown = false;
        }

        if (tank2.body.bottom > game.camera.view.bottom) {
            kbp2.stopDown = true;
        }
        else {
            kbp2.stopDown = false;
        }
    }
    else if (!body1 & !body2) {
        game.camera.focusOnXY(cameraFollow.x, cameraFollow.y);
    }
}

let createFire = function (tank) {

    if (gameStart) {
        if (tank.body) {
            let spriteBMP = null, spriteBoom = null;
            let wT = tank.width / 2, hT = tank.height / 2, xT = tank.x, yT = tank.y;
            if (tank.key == 'bosslevel5') {
                spriteBMP = game.add.sprite(xT, yT, "bosslevel5Dan");
                spriteBoom = game.add.sprite(-1000, -1000, 'boom');
                spriteBoom.scale.setTo(0);
                spriteBMP.danBossLevel5 = true;
                spriteBMP.anchor.set(0.5);
                spriteBMP.scale.set(0.22);
                spriteBMP.boomTank = spriteBoom;
                spriteBMP.fireDamage = tank.damage;
                groupBossLevel5Dan.add(spriteBMP);
                game.physics.enable(groupBossLevel5Dan, Phaser.Physics.ARCADE);
                game.physics.arcade.moveToXY(spriteBMP, tank.nhamTank.x, tank.nhamTank.y, 300);
            }
            else {
                let bmd = game.add.bitmapData(5, 5);
                bmd.ctx.beginPath();
                bmd.ctx.rect(0, 0, bmd.width, bmd.height);
                let spriteBMP1 = null, spriteBoom1 = null;
                let spriteBMP2 = null, spriteBoom2 = null;
                if (tank.angle == 0) {
                    spriteBMP = game.add.sprite(xT - 1.6, yT - hT, bmd);
                    spriteBoom = game.add.sprite(-1000, -1000, 'boom');
                    if (tank.level >= 12) {
                        spriteBMP1 = game.add.sprite(xT - 11, yT - hT, bmd);
                        spriteBoom1 = game.add.sprite(-1000, -1000, 'boom');
                        spriteBMP2 = game.add.sprite(xT + 8, yT - hT, bmd);
                        spriteBoom2 = game.add.sprite(-1000, -1000, 'boom');
                    }
                }
                else if (tank.angle == 90) {
                    spriteBMP = game.add.sprite(xT + wT, yT - 1.6, bmd);
                    spriteBoom = game.add.sprite(-1000, -1000, 'boom');
                    if (tank.level >= 12) {
                        spriteBMP1 = game.add.sprite(xT + wT, yT - 11, bmd);
                        spriteBoom1 = game.add.sprite(-1000, -1000, 'boom');
                        spriteBMP2 = game.add.sprite(xT + wT, yT + 8, bmd);
                        spriteBoom2 = game.add.sprite(-1000, -1000, 'boom');
                    }
                }
                else if (tank.angle == -180) {
                    spriteBMP = game.add.sprite(xT - 1.6, yT + hT, bmd);
                    spriteBoom = game.add.sprite(-1000, -1000, 'boom');
                    if (tank.level >= 12) {
                        spriteBMP1 = game.add.sprite(xT - 11, yT + hT, bmd);
                        spriteBoom1 = game.add.sprite(-1000, -1000, 'boom');
                        spriteBMP2 = game.add.sprite(xT + 8, yT + hT, bmd);
                        spriteBoom2 = game.add.sprite(-1000, -1000, 'boom');
                    }
                }
                else if (tank.angle == -90) {
                    spriteBMP = game.add.sprite(xT - wT, yT - 1.6, bmd);
                    spriteBoom = game.add.sprite(-1000, -1000, 'boom');
                    if (tank.level >= 12) {
                        spriteBMP1 = game.add.sprite(xT - wT, yT - 11, bmd);
                        spriteBoom1 = game.add.sprite(-1000, -1000, 'boom');
                        spriteBMP2 = game.add.sprite(xT - wT, yT + 8, bmd);
                        spriteBoom2 = game.add.sprite(-1000, -1000, 'boom');
                    }
                }

                if (tank.key == 'tank1') {
                    bmd.ctx.fillStyle = '#eefa29';
                }
                else if (tank.key == 'tank2') {
                    bmd.ctx.fillStyle = '#3e9e2c';
                }
                else {
                    bmd.ctx.fillStyle = '#FFFFFF';
                }
                bmd.ctx.fill();
                if (!tank.fire)
                    tank.fire = {};

                spriteBoom.scale.setTo(0);

                let addSprite = function (sprt, boom) {
                    sprt.dan = true;
                    sprt.keyTank = tank.key;
                    sprt.angleTank = tank.angle;
                    sprt.boomTank = boom;
                    sprt.speedFire = tank.speedFire;
                    sprt.fireDamage = tank.damage;

                    if (checkIsPlayers(tank))
                        groupFireTanks.add(sprt);
                    else
                        groupFireTanksEnimies.add(sprt);
                }

                addSprite(spriteBMP, spriteBoom);
                if (tank.level >= 12) {
                    addSprite(spriteBMP1, spriteBoom1);
                    addSprite(spriteBMP2, spriteBoom2);
                }

                game.physics.enable(groupFireTanks, Phaser.Physics.ARCADE);
                game.physics.enable(groupFireTanksEnimies, Phaser.Physics.ARCADE);

                let fireRun = function (sprite) {
                    if (sprite) {
                        let xVec = sprite.x, yVec = sprite.y;
                        if (sprite.angleTank == 0)
                            yVec = -10000;
                        else if (sprite.angleTank == 90)
                            xVec = 10000;
                        else if (sprite.angleTank == -180)
                            yVec = 10000;
                        else if (sprite.angleTank == -90)
                            xVec = -10000;
                        game.physics.arcade.moveToXY(sprite, xVec, yVec, sprite.speedFire);
                    }
                }
                fireRun(spriteBMP);
                fireRun(spriteBMP1);
                fireRun(spriteBMP2);
            }
        }
        music.tankFire.play();
        //game.world.sendToBack(tankFire.sprite);
    }
}

let fireBetweenTanks = function (fire, tank) {
    fire.collide = true;
    let battu = tank.battu;

    if (!battu)
        tank.life -= fire.fireDamage;

    if (tank.life <= 0) {
        let tankDied = null;
        if (tank.key == 'tank1') {
            tankDied = tank1Died;
            player1Enable = false;
        }
        else if (tank.key == 'tank2') {
            tankDied = tank2Died;
            player2Enable = false;
        }
        else {
            let roido = randomWithProbability((tank.level + 1) * 10);
            if (roido == 5) {
                roiDoRandom('itemLevelUp', tank, roido);
            }
        }

        if (tankDied) {
            tankDied.x = tank.x;
            tankDied.y = tank.y;
            tankDied.anchor.set(0.5);
            tankDied.visible = true;
        }

        boomEndObject(tank);
    }

    if (fire.danBossLevel5) {
        boomLevel5No(fire);
    }
    else {
        boomLevelNormal(fire);
    }
}

let fireComputer = function (tank) {
    let rdF = Math.floor((Math.random() * 5) + 1);
    let timeout = game.time.events.add(rdF * tank.delayFire, function () {
        if (tank.body) {
            if (!game.paused) {
                createFire(tank);
            }
            game.time.events.remove(timeout);
            fireComputer(tank);
        }
        else {
            game.time.events.remove(timeout);
        }
    }, this);
}

let movesComputer = function (tank) {
    let rdRote = Math.floor((Math.random() * 4) + 1);
    if (tank.body) {
        tank.keepUp = false;
        tank.keepDown = false;
        tank.keepLeft = false;
        tank.keepRight = false;

        if (rdRote == 1) {
            tank.keepUp = true;
        }
        else if (rdRote == 2) {
            tank.keepDown = true;
        }
        else if (rdRote == 3) {
            tank.keepLeft = true;
        }
        else if (rdRote == 4) {
            tank.keepRight = true;
        }
    }
}

let findPathToPlayer = function (tank, player) {
    if (gameStart) {
        if (!player.anthan | (player.anthan & tank.anthan)) {
            tank.keepUp = tank.keepDown = tank.keepLeft = tank.keepRight = false;
            let saiso = 10;
            let xSS = player.x + saiso, xSS_ = player.x - saiso;
            let ySS = player.y + saiso, ySS_ = player.y - saiso;

            if (xSS_ <= tank.x & tank.x <= xSS) {
                if (player.y >= tank.y | player.y >= tank.y) {
                    tank.keepDown = true;
                }
                else if (player.y < tank.y | player.y < tank.y) {
                    tank.keepUp = true;
                }
            }
            else if (ySS_ <= tank.y & tank.y <= ySS) {
                if (player.x >= tank.x | player.x >= tank.x) {
                    tank.keepRight = true;
                }
                else if (player.x < tank.x | player.x < tank.x) {
                    tank.keepLeft = true;
                }
            }
            else if (player.x > tank.x) {
                tank.keepRight = true;
            }
            else if (player.x < tank.x) {
                tank.keepLeft = true;
            }
            else if (player.y > tank.y) {
                tank.keepDown = true;
            }
            else if (player.y < tank.y) {
                tank.keepUp = true;
            }
            game.physics.arcade.moveToXY(tank, player.x, player.y, tank.speed);
        }
    }
}

let computerFindPlayers = function (tank, type) {
    let rdtimeout = Math.floor((Math.random() * 10) + 2);
    if (!type) {
        let rdRote = Math.floor((Math.random() * 2) + 1);
        tank.autoMove = rdRote;
    }
    else {
        tank.autoMove = 3;
        movesComputer(tank);
    }

    let timeout = game.time.events.add(rdtimeout * 1000, function () {
        computerFindPlayers(tank);
        game.time.events.remove(timeout);
    });
}


let randomWithProbability = function (tyle) {

    let forNumber = function (number) {
        let arrTyLe1 = [...arrTyLe];
        for (let i = 0; i < number; i++) {
            arrTyLe1[i] = 1;
        }
        arrTyLe1 = shuffleArray(arrTyLe1);
        arrTyLe1 = shuffleArray(arrTyLe1);
        let idx = Math.floor(Math.random() * (arrTyLe1.length - 1));
        return arrTyLe1[idx];
    }

    let result = 0;
    if (forNumber(tyle) == 1)
        result = 5;

    return result;
}

let roiDoRandom = function (name, tank, roido) {
    let ok = true;
    if (player1EnSav & player2EnSav) {
        ok = !(tank1.level >= 24 & tank2.level >= 24);
    }
    else if (player1EnSav) {
        ok = !(tank1.level >= 24);
    }
    else if (player2EnSav) {
        ok = !(tank2.level >= 24);
    }
    if (ok) {
        let item = game.add.sprite(tank.x, tank.y, name);
        item.roido = roido;
        item.anchor.set(0.5);
        groupItems.add(item);
        game.physics.enable(groupItems, Phaser.Physics.ARCADE);
    }
}

let shuffleArray = function (array) {
    for (let i = array.length - 1; i > 0; i--) {
        let j = Math.floor(Math.random() * (i + 1));
        let temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
    return array;
}

//#endregion function Custom
