let boomLevelNormal = function (sprite) {
    sprite.dan = false;
    sprite.danBossLevel5 = false;
    let boomTank = sprite.boomTank;
    boomTank.anchor.setTo(0.5, 0.5);
    boomTank.x = sprite.x + 1.6;
    boomTank.y = sprite.y;
    boomTank.scale.setTo(0.2);
    sprite.x = -10000;
    music.tankBoom.play();
    let numberS = 0;
    let intervalId = game.time.events.loop(100, function () {
        if (numberS == 0 | numberS == 2)
            boomTank.scale.setTo(0.5);
        if (numberS == 1)
            boomTank.scale.setTo(0.8);
        if (numberS == 3)
            boomTank.scale.setTo(0.2);
        else if (numberS == 4) {
            boomTank.destroy();
            sprite.destroy();
            boomTank = undefined;
            game.time.events.remove(intervalId);
        }
        numberS++;
    });
}

let boomLevel5No = function (sprite) {
    sprite.danBossLevel5 = false;
    sprite.dan = false;
    let boomTank = sprite.boomTank;
    boomTank.anchor.setTo(0.5, 0.5);
    boomTank.x = sprite.x;
    boomTank.y = sprite.y;
    boomTank.scale.setTo(0.5);
    sprite.x = -10000;
    music.tankBoom.play();
    let numberS = 0;
    let intervalId = game.time.events.loop(100, function () {
        if (numberS == 0 | numberS == 2)
            boomTank.scale.setTo(1);
        if (numberS == 1)
            boomTank.scale.setTo(1.5);
        if (numberS == 3)
            boomTank.scale.setTo(0.5);
        else if (numberS == 4) {
            boomTank.destroy();
            sprite.destroy();
            boomTank = undefined;
            game.time.events.remove(intervalId);
        }
        numberS++;
    });
}

let boomEndObject = function (tank) {
    tank.end = true;
    let boomTank = game.add.sprite(-1000, -1000, 'boomEnd');
    boomTank.anchor.setTo(0.5, 0.5);
    boomTank.x = tank.x;
    boomTank.y = tank.y;
    let tyle = tank.width / boomTank.width;
    boomTank.scale.setTo(tyle);
    music.tankBoom.play();
    let numberS = 0;

    if (tank.key == 'bosslevel10') {
        __createTankEnimiesOfLevel(1, 10);
        __createTankEnimiesOfLevel(2, 30);
        __createTankEnimiesOfLevel(3, 20);
        __createTankEnimiesOfLevel(4, 10);
        __createTankEnimiesOfLevel(5, 5);
        groupTanksEnimies.forEach(tankC => {
            fireComputer(tankC);
            computerFindPlayers(tankC);
        });
        game.physics.enable(groupTanksEnimies, Phaser.Physics.ARCADE);
    }
    tank.destroy();
    let intervalId = game.time.events.loop(100, function () {
        if (numberS == 0 | numberS == 2)
            boomTank.scale.setTo(tyle * 3);
        if (numberS == 1)
            boomTank.scale.setTo(tyle * 6);
        if (numberS == 3)
            boomTank.scale.setTo(tyle * 4);
        else if ([4, 5, 6].lastIndexOf(numberS) > -1) {
            let intervalId2 = game.time.events.loop(10, function () {
                if (boomTank) {
                    boomTank.angle += 3;
                    if (boomTank.angle >= 90)
                        game.time.events.remove(intervalId2);
                }
            });
        }
        else if (numberS == 7) {
            boomTank.destroy();
            boomTank = undefined;
            game.time.events.remove(intervalId);
        }
        numberS++;
    });
}

let laserFire = function (laser, laser_, tank) {

    let updateLaserAlpha = function (size) {
        if (laser) {
            laser.scale.setTo(30, size);
            if ([-90, 90].lastIndexOf(laser.angle) <= -1)
                laser_.scale.setTo(30, size);
            else
                laser_.scale.setTo(size, 30);
        }
    }

    let numberS = 0;
    let intervalId = game.time.events.loop(200, function () {
        if (numberS == 0 | numberS == 2) {
            updateLaserAlpha(0.2);
        }
        else if (numberS == 1) {
            updateLaserAlpha(0.3);
        }
        else if (numberS == 3) {
            updateLaserAlpha(0.5);
        }
        else if (numberS == 4) {
            updateLaserAlpha(0.7);
        }
        else if (numberS == 5) {
            laser.alpha = 0.8;
        }
        else if (numberS == 6) {
            laser.alpha = 0.7;
        }
        else if (numberS == 7) {
            laser.alpha = 0.6;
        }
        else if (numberS == 8) {
            laser.alpha = 0.5;
        }
        else if (numberS == 9) {
            laser.alpha = 0.3;
        }
        else {
            laser.destroy();
            laser_.destroy();
            tank.body.moves = true;
            game.time.events.remove(intervalId);
        }
        numberS++;
    });
}

let updateLevel = function (tank, ando) {
    let kbpItem = getKeyBoard(tank);
    let kbpItemRoot = getKeyBoard(tank, true);
    if (tank.key == 'tankC') {
        kbpItem = tank;
    }

    if (ando)
        kbpItem.level++;

    if (kbpItem.level <= 0) {
        tank.frame = 0;
        kbpItem.damage = kbpItemRoot.damage;
        kbpItem.speed = kbpItemRoot.speed;
        kbpItem.speedFire = kbpItemRoot.speedFire;
        kbpItem.delayFire = kbpItemRoot.delayFire;
        kbpItem.life = kbpItemRoot.life;
    }
    else if (kbpItem.level >= 1 & kbpItem.level < 3) {
        tank.frame = 1;
        kbpItem.damage = kbpItemRoot.damage + 1;
        kbpItem.speed = kbpItemRoot.speed + 50;
        kbpItem.speedFire = kbpItemRoot.speedFire + 100;
        kbpItem.delayFire = kbpItemRoot.delayFire - 150;
        kbpItem.life = kbpItemRoot.life + 1;
    }
    else if (kbpItem.level >= 3 & kbpItem.level < 6) {
        tank.frame = 2;
        kbpItem.damage = kbpItemRoot.damage + 2;
        kbpItem.speed = kbpItemRoot.speed + 100;
        kbpItem.speedFire = kbpItemRoot.speedFire + 150;
        kbpItem.delayFire = kbpItemRoot.delayFire - 300;
        kbpItem.life = kbpItemRoot.life + 3;
    }
    else if (kbpItem.level >= 6 & kbpItem.level < 12) {
        tank.frame = 3;
        kbpItem.damage = kbpItemRoot.damage + 3;
        kbpItem.speed = kbpItemRoot.speed + 150;
        kbpItem.speedFire = kbpItemRoot.speedFire + 200;
        kbpItem.delayFire = kbpItemRoot.delayFire - 450;
        kbpItem.life = kbpItemRoot.life + 7;
    }
    else if (kbpItem.level >= 12 & kbpItem.level < 24) {
        tank.frame = 4;
        kbpItem.damage = kbpItemRoot.damage + 4;
        kbpItem.speed = kbpItemRoot.speed + 200;
        kbpItem.speedFire = kbpItemRoot.speedFire + 300;
        kbpItem.delayFire = kbpItemRoot.delayFire - 600;
        kbpItem.life = kbpItemRoot.life + 15;
    }
    else if (kbpItem.level >= 24) {
        tank.frame = 5;
        kbpItem.damage = kbpItemRoot.damage + 5;
        kbpItem.speed = kbpItemRoot.speed + 220;
        kbpItem.speedFire = kbpItemRoot.speedFire + 400;
        kbpItem.delayFire = kbpItemRoot.delayFire - 700;
        kbpItem.life = kbpItemRoot.life + 31;
    }
    kbpItem.life = kbpItem.life * kbpItemRoot.themmau;

    if (ando & [1, 3, 6, 12, 24].lastIndexOf(kbpItem.level) > -1) {
        tankReceivedItems(tank, kbpItem);
    }
}

let resetAfterDied = function (kbp, kbpbk) {
    kbp.level = kbpbk.level;
}

let tankReceivedItems = function (tank, kbpItem) {
    tank.damage = kbpItem.damage;
    tank.speed = kbpItem.speed;
    tank.speedFire = kbpItem.speedFire;
    tank.delayFire = kbpItem.delayFire;
    tank.life = kbpItem.life;
    tank.level = kbpItem.level;
}